#2.Introduction to Python3
# a)Printing your biodata on the screen
# Define a function 'personal_details'.
def personal_details():
 # Define variables 'name' and 'age' and assign values to them.
 name, age = "Simon", 19
 # Define a variable 'address' and assign a value to it.
 address = "Bangalore, Karnataka, India"
 # Print the personal details using string formatting.
 print("Name: {}\nAge: {}\nAddress: {}".format(name, age, address))
# Call the 'personal_details' function to display the details.
personal_details()
